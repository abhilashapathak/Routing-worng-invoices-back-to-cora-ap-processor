({
            /**
             * Executes on creation of SObject
             * Processing passes 
             *  - if resolve and success == true
             * @param sobjectName Selected SObjectName
             * @param sobjectData Old SObject Data
             * @param lineItems list of line items
             * @param attachmentList list of files attached
             * @param userLocale locale information of logged in user's locale
             */
            validateOnSObjectCreate: async function(sobjectName, sobjectData, lineItems, attachmentList, userLocale) {
                return new Promise((resolve, reject) => {
					
					

                    console.log(arguments);

                    /* 
                    // Success response
                    resolve({
                        success: true, 
                        data: { 
                            sobjectData: {}, 
                            lineItems: [] 
                        }
                    }); */

                    /* 
                    // Error response
                    resolve({
                        success: false, 
                        message: 'Some error from server'
                    }); */
					
					try {
						var polarisNumber = '';
						var invoiceNoValidationString = /[!@#$%^&*? ]/ig;
						//var userData = JSON.parse(JSON.parse(atob(localStorage.getItem("user"))).userdata);
						var user =    JSON.parse(CryptoJS.AES.decrypt(sessionStorage.getItem("user"),"esm-configurable").toString(CryptoJS.enc.Utf8).replace(/&quot;/g, '"'));
						var userData = JSON.parse(user.userdata);
						
						var work_doc_BU_mapping = JSON.parse('{"Direct Non PO Invoice":{"Credit Memo":["Cordis","Expense","Harvard Drugs","Medical","MPT","Nuclear","Patient Recovery-Finished Goods","Patient Recovery-Raw Material","Pharma","Presource","Repack","Medical-Twinsburg"],"All Other Charges Payback":["Cordis","Expense","Harvard Drugs","Medical","MPT","Nuclear","Patient Recovery-Finished Goods","Patient Recovery-Raw Material","Pharma","Presource","Repack","Medical-Twinsburg"]},"Indirect Non PO Invoice":{"Regular Invoice":["Cordis","Expense","Medical","Medical-Twinsburg"],"Credit Memo":["Expense"],"Ariba Credit Memo":["Expense"],"Exception to CAP":["Cordis","Expense","Medical"],"Adobe Sign":["Expense"],"TWA-OUS":["Cordis","Expense","Medical"],"Utilities":["Expense","Medical-Twinsburg"]},"Indirect PO Invoice":{"Ariba PO":["Expense"],"Regular PO":["Cordis","Expense","Medical","Medical-Twinsburg"]},"Upload Template":{"Exception to CAP":["Expense","Medical"],"Unapproved":["Expense","Medical"],"Check Tracker":["Cordis","Expense","Harvard Drugs","Medical","MPT","Nuclear","Patient Recovery-Finished Goods","Patient Recovery-Raw Material","Pharma","Presource","Repack","Medical-Twinsburg"],"MR11":["Expense"],"Nuclear Bayer Upload":["Nuclear"]},"Direct PO Invoice":{"MR11 Reversals":["Medical","Patient Recovery-Finished Goods","Nuclear"],"Others":["Cordis","Medical","MPT","Patient Recovery-Finished Goods","Patient Recovery-Raw Material","Presource","Medical-Twinsburg","Harvard Drugs","Nuclear","Pharma","Repack"],"Raw Material":["Medical","Patient Recovery-Raw Material"]}}');
						console.log(sobjectData.CAH_Heroku_Work_Type__c);
						
						function parseDate(str) {
							var mdy = str.split('/');
							return new Date(mdy[2], mdy[0]-1, mdy[1]);
						}
						
						function datediff(first, second) {
							return Math.round((second-first)/(1000*60*60*24));
						}
						
						if(work_doc_BU_mapping.hasOwnProperty(sobjectData.CAH_Heroku_Work_Type__c)){
							if(work_doc_BU_mapping[sobjectData.CAH_Heroku_Work_Type__c].hasOwnProperty(sobjectData.CAH_Heroku_Document_Type__c)){
								if(work_doc_BU_mapping[sobjectData.CAH_Heroku_Work_Type__c][sobjectData.CAH_Heroku_Document_Type__c].indexOf(sobjectData.CAH_Business_Type__c) === -1){
									resolve({
										success: false,
										message: sobjectData.CAH_Business_Type__c+' is not allowed with '+sobjectData.CAH_Heroku_Work_Type__c+" work type and "+sobjectData.CAH_Heroku_Document_Type__c+" document type"
									});
								}
							}
						}
						
						if(sobjectData.CAH_TWA_OUS_Approval_Type__c === 'DOA'){
							if(sobjectData.hasOwnProperty("CoraAP__First_Approver__c") && 
							sobjectData.hasOwnProperty("CAH_Second_Approver__c") && 
							(sobjectData.CoraAP__First_Approver__c !== undefined && sobjectData.CoraAP__First_Approver__c !== null) &&
							(sobjectData.CAH_Second_Approver__c !== undefined && sobjectData.CAH_Second_Approver__c !== null) &&
							sobjectData.CoraAP__First_Approver__c === sobjectData.CAH_Second_Approver__c){
								resolve({
									success: false,
									message: 'Both Approvers can not be same.'
								});
							}
						}
				// Added for Wave 3 - Mitali - 18/12/2020 - Start		
						if((sobjectData.CAH_Heroku_Document_Type__c === 'Exception to CAP' || sobjectData.CAH_Heroku_Document_Type__c === 'Adobe Sign' && sobjectData.CAH_Heroku_Document_Sub_Category__c === 'Pre-Approved') && sobjectData.CAH_Is_Approval_Email_Attached__c === 'No'){
							resolve({
								success: false,
								message: 'It is required to attach approval email.'
							});
						}

						
						
						
					// Added for Wave 3 - Mitali - 18/12/2020 - End

						if(sobjectData.CoraAP__Invoice_Date__c !== undefined && sobjectData.CoraAP__Invoice_Date__c !== null){
							//04/23/2020-MM/DD/YYYY
							var invoiceDate = new Date(sobjectData.CoraAP__Invoice_Date__c);
							var currentDate = new Date();
							var difference = datediff(parseDate(currentDate.getMonth()+'/'+currentDate.getDate()+'/'+currentDate.getFullYear()), parseDate(invoiceDate.getMonth()+'/'+invoiceDate.getDate()+'/'+invoiceDate.getFullYear()));
							if(difference > 730){
								resolve({
									success: false,
									message: 'Invoice date cannot be more than two years in future.'
								});
							}
							if(difference < 0){
								if((difference*-1) > 1095){
									resolve({
										success: false,
										message: 'Invoice date cannot be more than three years in past.'
									});
								}
							}
						}
						
						if(userData.CoraAP__AP_Designation__c === 'Non Manager' || userData.CoraAP__AP_Designation__c === 'Supervisor'){
							if(sobjectData.CAH_Tower__c === 'Expense' && !userData.CAH_Is_Expense_User__c){
								resolve({
									success: false,
									message: 'You are not allowed to create invoice in Expense tower.'
								});
							}
							
							if(sobjectData.CAH_Tower__c === 'Medical' && !userData.CAH_Is_Medical_User__c){
								resolve({
									success: false,
									message: 'You are not allowed to create invoice in Medical tower.'
								});
							}
							
							if(sobjectData.CAH_Tower__c === 'Pharma' && !userData.CAH_Is_Pharma_User__c){
								resolve({
									success: false,
									message: 'You are not allowed to create invoice in Pharma tower.'
								});
							}
						}
						
						if(sobjectData.CAH_Notes__c){
							var notesValue = sobjectData.CAH_Notes__c.match(invoiceNoValidationString);
							if(invoiceNoValue || sobjectData.CAH_Notes__c.length > 25){
								resolve({
									success: false,
									message: 'Header text should contain only alphanumneric values and must not be more than 25 character long.'
								});
							}
						}
						
						if(sobjectData.CAH_Gross_Amount__c !== null && sobjectData.CAH_Gross_Amount__c !== undefined){
							var amount = sobjectData.CAH_Heroku_Work_Type__c == 'Upload Template' ? sobjectData.CAH_Highest_Header_Amount__c : sobjectData.CAH_Net_Amount__c;
							var totalAmount = amount;
							if(sobjectData.hasOwnProperty("CAH_Other_Taxes__c") &&
							(sobjectData.CAH_Other_Taxes__c !== undefined && sobjectData.CAH_Other_Taxes__c !== null)){
								totalAmount += sobjectData.CAH_Other_Taxes__c;
							}
							if(Math.round(sobjectData.CAH_Gross_Amount__c * 100) !== Math.round(totalAmount * 100)){
								resolve({
									success: false,
									message: 'Please correct gross amount.'
								});
							}
							else if(Math.round(sobjectData.CAH_Gross_Amount__c * 100) !== Math.round(amount * 100)){
								/*reject({
									success: false,
									message: 'Please correct gross amount.'
								});*/
							}
						}
						
						if(sobjectData.CAH_Heroku_Work_Type__c == 'Upload Template' && 
						sobjectData.CAH_ERP_System__c !== null && sobjectData.CAH_ERP_System__c !== undefined && 
						sobjectData.CAH_ERP_System__c != 'Pharma Corp' && sobjectData.CAH_ERP_System__c != 'TPM' && sobjectData.CAH_ERP_System__c != 'Tiny Term'&& !(sobjectData.CAH_ERP_System__c == 'JDE' && sobjectData.CoraAP__Bill_To_Country__c == 'Canada')){
							resolve({
								success: false,
								message: sobjectData.CAH_ERP_System__c + ' is not allowed in ' + sobjectData.CAH_Heroku_Work_Type__c + ' for '+ sobjectData.CoraAP__Bill_To_Country__c +' Business Location here.'
							});
						}
						
						if(sobjectData.CAH_Heroku_Work_Type__c == 'Indirect PO Invoice' && sobjectData.CAH_Heroku_Document_Type__c === 'Ariba PO' && sobjectData.CAH_ERP_System__c != 'Ariba'){
							resolve({
								success: false,
								message: sobjectData.CAH_ERP_System__c + ' is not allowed in ' + sobjectData.CAH_Heroku_Document_Type__c + ' here.'
							});
						}
			// Added for Wave 3 - Condition added for BPCS and Tiny Term - MItali - 18/12/2020			
						if(sobjectData.CAH_Heroku_Document_Type__c === 'Regular PO' && sobjectData.CAH_ERP_System__c != 'Pharma Corp' && sobjectData.CAH_ERP_System__c != 'TPM' && sobjectData.CAH_ERP_System__c != 'Oracle' && sobjectData.CAH_ERP_System__c != 'SAP by Design' && sobjectData.CAH_ERP_System__c != 'BPCS' && sobjectData.CAH_ERP_System__c != 'Tiny Term'){
							resolve({
								success: false,
								message: sobjectData.CAH_ERP_System__c + ' is not allowed in ' + sobjectData.CAH_Heroku_Document_Type__c + ' here.'
							});
						}
			// Added for Wave 3 - Mitali - 18/12/2020 - Start			
						 if((sobjectData.CoraAP__Bill_To_Country__c === 'Ireland' || sobjectData.CoraAP__Bill_To_Country__c === 'Germany') && sobjectData.CAH_ERP_System__c != 'BPCS'){
							resolve({
								success: false,
								message: sobjectData.CAH_ERP_System__c + ' is not allowed with ' + sobjectData.CoraAP__Bill_To_Country__c + ' Business Location.'
							});
						}
						
						if(sobjectData.CoraAP__Bill_To_Country__c === 'Puerto Rico' && sobjectData.CAH_ERP_System__c != 'Tiny Term'){
							resolve({
								success: false,
								message: sobjectData.CAH_ERP_System__c + ' is not allowed with ' + sobjectData.CoraAP__Bill_To_Country__c + ' Business Location.'
							});
						}
						
						if(sobjectData.CoraAP__Bill_To_Country__c === 'Singapore' && sobjectData.CAH_ERP_System__c != 'SAP P30'){
							resolve({
								success: false,
								message: sobjectData.CAH_ERP_System__c + ' is not allowed with ' + sobjectData.CoraAP__Bill_To_Country__c + ' Business Location.'
							});
						}
					// Added for Wave 3 - Mitali - 18/12/2020 - End

						if(sobjectData.CAH_Polaris_number__c !== null && sobjectData.CAH_Polaris_number__c !== undefined){
							var polarisValue = sobjectData.CAH_Polaris_number__c.match(polarisNumber);
							if(polarisValue == null){
								resolve({
									success: false,
									message: 'Please correct polaris number value.'
								});
							}
						}
						
						//Changes done by Sohil for P2. Start.
						if(sobjectData.CAH_Heroku_Document_Type__c !== 'TWA-OUS' && sobjectData.CoraAP__Invoice_No__c !== null && sobjectData.CoraAP__Invoice_No__c !== undefined){
							var invoiceNoValue = sobjectData.CoraAP__Invoice_No__c.match(invoiceNoValidationString);
							if(invoiceNoValue || sobjectData.CoraAP__Invoice_No__c.length > 16){
								resolve({
									success: false,
									message: 'Invoice no should contain only alphanumneric values and must not be more than 16 characters.'
								});
							}
						}
						//Changes done by Sohil for P2. End.
							
						if(sobjectData.CAH_Cost_Center__c !== null && sobjectData.CAH_Cost_Center__c !== undefined){
							if(sobjectData.CAH_Cost_Center__c.toString().length > 10){
								resolve({
									success: false,
									message: 'Cost Center length can not be more than 10.'
								});
							}
						}
						// Enhanced Change Start
						if(sobjectData.CAH_Heroku_Work_Type__c === 'Indirect Non PO Invoice' || sobjectData.CAH_Heroku_Work_Type__c == 'Direct Non PO Invoice'){
							if(lineItems && lineItems.length > 0){
								var taxCodeError = false, indirectTaxCodeError = false, directTaxCodeError = false,amountInNegetive = false;
								for(var i = 0; i < lineItems.length; i++){
									var invoiceLineItem = lineItems[i];
									if(invoiceLineItem.CAH_Amount__c < 0){
										amountInNegetive = true;
										break;
									}
									if((!invoiceLineItem.CAH_Tax_Code__c && (sobjectData.CAH_ERP_System__c === 'Pharma Corp' || sobjectData.CAH_ERP_System__c === 'TPM')) || (!invoiceLineItem.CAH_Tax_Code_Value__c && ((sobjectData.CAH_ERP_System__c !== 'Pharma Corp' && sobjectData.CAH_ERP_System__c !== 'TPM')))){
										taxCodeError = true;
										break;
									}
									 else{
							       if(invoiceLineItem.CAH_Tax_Code__c !== undefined && invoiceLineItem.CAH_Tax_Code__c !== null)
							        {
								     if(sobjectData.CAH_Heroku_Work_Type__c == 'Indirect Non PO Invoice' && !invoiceLineItem.CAH_Tax_Code__r.Name.startsWith('I')){
									       indirectTaxCodeError = true;
									         break;
								     }
									if(sobjectData.CAH_Heroku_Work_Type__c == 'Direct Non PO Invoice' && !invoiceLineItem.CAH_Tax_Code__r.Name.startsWith('D')){
									     directTaxCodeError = true;
									      break;
								     }
							         }
							        if(invoiceLineItem.CAH_Tax_Code_Value__c !== undefined && invoiceLineItem.CAH_Tax_Code_Value__c !== null)
							        {
							          if(sobjectData.CAH_Heroku_Work_Type__c == 'Indirect Non PO Invoice' && !invoiceLineItem.CAH_Tax_Code_Value__c.startsWith('I')){
									        indirectTaxCodeError = true;
									           break;
								     }
							         if(sobjectData.CAH_Heroku_Work_Type__c == 'Direct Non PO Invoice' && !invoiceLineItem.CAH_Tax_Code_Value__c.startsWith('D')){
									      directTaxCodeError = true;
									        break;
								     }	
							       }	
												
								
							     }
									
									
									//Commented mohana
									/*else{
										if(sobjectData.CAH_Heroku_Work_Type__c == 'Indirect Non PO Invoice' && !invoiceLineItem.CAH_Tax_Code__r.Name.startsWith('I')){
											indirectTaxCodeError = true;
											break;
										}
										if(sobjectData.CAH_Heroku_Work_Type__c == 'Direct Non PO Invoice' && !invoiceLineItem.CAH_Tax_Code__r.Name.startsWith('D')){
											directTaxCodeError = true;
											break;
										}
									}*/
								}
								//Changes done by Sohil for P2. Start.
								if(amountInNegetive){
									resolve({
										success: false,
										message: 'Amount can should only be positive on Invoice line item.'
									});
								}
								if(indirectTaxCodeError){
									resolve({
										success: false,
										message: 'Please select Tax code as I0 or I1 on line level.'
									});
								}
								if(directTaxCodeError){
									resolve({
										success: false,
										message: 'Please select Tax code as D0 or D1 on line level.'
									});
								}
								// Enhanced Changes End.
								//Changes done by Sohil for P2. End.
								if(taxCodeError){
									resolve({
										success: false,
										message: 'Tax code is mandatory on line level.'
									});
								}
							}
						}
						
						var isCostCenterRequired = false;
						var isProfitCenterRequired = false;
						var isGLCodeRequired = false;
						var isCostAndProfitBothSelected = false;
						var isLineTextIssue = false;
						var isAmtRequired = false;
						var isWBSError = false;

						if(sobjectData.CAH_Heroku_Work_Type__c === 'Direct Non PO Invoice' || sobjectData.CAH_Heroku_Work_Type__c === 'Indirect Non PO Invoice'){
							if(lineItems && lineItems.length > 0){
								for(var i = 0; i < lineItems.length; i++){
									var invoiceLineItem = lineItems[i];
									var glCode;
									if(invoiceLineItem.CAH_Text__c){
										var lineTextValue = invoiceLineItem.CAH_Text__c.match(invoiceNoValidationString);
										if(lineTextValue || invoiceLineItem.CAH_Text__c.length > 25){
											isLineTextIssue = true;
											break;
										}
									}
									if((sobjectData.CAH_ERP_System__c === 'TPM' || sobjectData.CAH_ERP_System__c === 'Pharma Corp') && invoiceLineItem.CoraAP__GL_Code__r.Name){
										
										if(invoiceLineItem.CAH_WBS__c && invoiceLineItem.CAH_WBS__r.Name && !invoiceLineItem.CAH_WBS__r.Name.startsWith('B')){
											isWBSError = true;
											break
										}
										
										if(invoiceLineItem.CAH_WBS__c && invoiceLineItem.CAH_WBS__r.Name && invoiceLineItem.CAH_WBS__r.Name.startsWith('B')){
										
										} else{

											glCode = '' + parseInt(invoiceLineItem.CoraAP__GL_Code__r.Name);
											if(invoiceLineItem.CoraAP__GL_Code__r.Name && 
											( glCode.startsWith('1') || glCode.startsWith('2') || glCode.startsWith('3')  || glCode.startsWith('4') || glCode.startsWith('5'))) {
												if(!invoiceLineItem.CAH_Profit_Center__c){
													isProfitCenterRequired = true;
													break;
												}
												if(invoiceLineItem.CAH_Profit_Center__c && invoiceLineItem.CoraAP__CostCode__c){
													isCostAndProfitBothSelected = true;
													break;
												}
											}
											else if(invoiceLineItem.CoraAP__GL_Code__r.Name && (glCode.startsWith('6') || glCode.startsWith('7') || glCode.startsWith('8'))){
												if(!invoiceLineItem.CoraAP__CostCode__c ){
													isCostCenterRequired = !invoiceLineItem.CoraAP__CostCode__c;
													//isProfitCenterRequired = !invoiceLineItem.CAH_Profit_Center__c;
													break;
												}
												if(invoiceLineItem.CAH_Profit_Center__c && invoiceLineItem.CoraAP__CostCode__c){
													isCostAndProfitBothSelected = true;
													break;
												}
											}
										}
									}else if(sobjectData.CoraAP__Bill_To_Country__c === 'Canada' && !invoiceLineItem.CAH_Amount__c){
									   isAmtRequired = true;
										break;

									}
									else if((sobjectData.CAH_ERP_System__c !== 'TPM' && sobjectData.CAH_ERP_System__c !== 'Pharma Corp') && invoiceLineItem.CAH_GL_Code_text__c){
										if(sobjectData.CAH_ERP_System__c !== 'SAP by Design' && sobjectData.CAH_ERP_System__c !== 'FACTS' && sobjectData.CAH_ERP_System__c !== 'JDE' && sobjectData.CAH_ERP_System__c !== 'PRMS' && sobjectData.CAH_ERP_System__c !== 'BPCS' && sobjectData.CAH_ERP_System__c !== 'MAPICS' && sobjectData.CAH_ERP_System__c !== 'Ariba'){

											if(invoiceLineItem.CAH_WBS_text__c && !invoiceLineItem.CAH_WBS_text__c.startsWith('B')){
												isWBSError = true;
												break;
											}

											if(invoiceLineItem.CAH_WBS_text__c && invoiceLineItem.CAH_WBS_text__c.startsWith('B')){
											} else{

												glCode = '' + parseInt(invoiceLineItem.CAH_GL_Code_text__c);
												if(!invoiceLineItem.CAH_Profit_Center_text__c && 
												(glCode.startsWith('1') || glCode.startsWith('2') || glCode.startsWith('3') || glCode.startsWith('4') || glCode.startsWith('5'))){
													isProfitCenterRequired = true;
													break;
												}
												else if((!invoiceLineItem.CAH_Profit_Center_text__c || !invoiceLineItem.CAH_Cost_Center__c) && 
												(glCode.startsWith('6') || glCode.startsWith('7') || glCode.startsWith('8'))){                    
													isCostCenterRequired = !invoiceLineItem.CAH_Cost_Center__c;
													//isProfitCenterRequired = !invoiceLineItem.CAH_Profit_Center_text__c;
													break;
												}
											}
										}
										else{
											if(sobjectData.CAH_ERP_System__c === 'SAP by Design'){
												isCostCenterRequired = !invoiceLineItem.CAH_Cost_Center__c;
											}
										}
									}
								}
								
								if(isWBSError){
									resolve({
										success: false,
										message: 'WBS not starting with B is not allowed. Either remove it or select anyone starting with B.'
									});
								}
								
								if(isCostCenterRequired){        
									resolve({
										success: false,
										message: 'Please select at least one Cost Center'
									});
								}
								
								if(isProfitCenterRequired){
									resolve({
										success: false,
										message: 'Please select at least one Profit Center'
									});
								}
								if(isCostAndProfitBothSelected){
									resolve({
										success: false,
										message: 'Please select either cost center or profit center'
									});
								}
								if(isGLCodeRequired){
									resolve({
										success: false,
										message: 'Please select at least one GL Code.'
									});
								}
								if(isAmtRequired){
									resolve({
										success: false,
										message: 'Please select at least one Line Net Amount.'
									});
								}
								if(isLineTextIssue){
									resolve({
										success: false,
										message: 'Text should contain only alphanumneric values and must not be more than 25 character long.'
									});
								}
							}
						}
						
						var amt = sobjectData.CAH_Gross_Amount__c;
						if(sobjectData.CAH_Heroku_Document_Type__c === 'TWA-OUS'){
							amt = sobjectData.CAH_Invoice_Amount__c;
						}
						
						if(sobjectData.CAH_Heroku_Work_Type__c == 'Upload Template'){
							amt = sobjectData.CAH_Highest_Header_Amount__c;
						}
						if(amt < 0){
							resolve({
								success: false,
								message: 'Negative amount not allowed.'
							});
						}
						
						//Credit Memo removed by Sohil for P2.
						//if(invoiceData.lineItem && invoiceData.lineItem.length > 0 && invoiceData.CAH_Net_Amount__c && invoiceData.CAH_Heroku_Document_Type__c != 'Credit Memo'){
						if(lineItems && lineItems.length > 0 && sobjectData.CAH_Net_Amount__c ){
							var headerAmt = sobjectData.CAH_Net_Amount__c;
							/*if(invoiceData.CAH_Heroku_Document_Type__c === 'TWA-OUS'){
								invoiceAmount = invoiceData.CAH_Invoice_Amount__c;
							}
							
							if(invoiceData.CAH_Heroku_Work_Type__c == 'Upload Template'){
								invoiceAmount = invoiceData.CAH_Highest_Header_Amount__c;
							}*/
							
							var lineLevelAmt = 0.0;
							for (var j = 0; j < lineItems.length; j++) {
								if(lineItems[j].isDeleted !== true){
									var amt = lineItems[j].CAH_Amount__c ? lineItems[j].CAH_Amount__c : 0.0;
									lineLevelAmt = +lineLevelAmt + +amt;	
								}
							}
							console.log('test headerAmt is '+headerAmt + ' test lineLevelAmt is '+lineLevelAmt);
							if (Math.round(headerAmt * 100) !== Math.round(lineLevelAmt * 100)) {
								console.log('test in differenct amount block');
								resolve({
									success: false,
									message: 'Header Net Amount is greater than sum of line items by ' + ((headerAmt-lineLevelAmt).toFixed(2))
								});
							}
						}
						
						var isCCandPCMismatch = false;
						if(sobjectData.CAH_Heroku_Work_Type__c === 'Indirect Non PO Invoice' && (sobjectData.CAH_ERP_System__c === 'TPM' || (sobjectData.CAH_ERP_System__c === 'Pharma Corp' && sobjectData.CoraAP__Bill_To_Country__c !== 'Canada' ))){
							for(var i = 0; i<lineItems.length; i++){
								var invoiceLineItem = lineItems[i];
								if( invoiceLineItem.CoraAP__CostCode__c && invoiceLineItem.CoraAP__APLegalEntity__c ){
									var companyCodeVal = invoiceLineItem.CoraAP__APLegalEntity__r ? invoiceLineItem.CoraAP__APLegalEntity__r.Name.substring(0,3) : '';
									var profitCenterVal = invoiceLineItem.CoraAP__CostCode__r ? invoiceLineItem.CoraAP__CostCode__r.Name : '';
									if( companyCodeVal && profitCenterVal &&  !eval('/'+companyCodeVal+'.*/').test(profitCenterVal)){
										isCCandPCMismatch = true;
										break;
									}
								}
							}
						}
						
						if(isCCandPCMismatch){
							resolve({
								success: false,
								message: 'Invoice line item\'s Company Code and Cost Center are mismatched.'
							});
						}
						
						/*if(invoiceData.hasOwnProperty('CoraAP__Invoice_Date__c') && !invoiceData.CoraAP__Invoice_Date__c){
							reject({
								success: false,
								message: 'Please select Invoice Date.'
							});
						}*/
						
						var performWebServiceCall = (url, myBody) => {
							return fetch(url, {
								method: 'POST',
								body: JSON.stringify(myBody),
								headers: {
									'Content-Type': 'application/json'
								}
							});
						}
								
						var verifyApprovalHierarchy = (sobjectData) => {
							if(sobjectData.CAH_Sourcing_Manager__c || sobjectData.CoraAP__First_Approver__c || sobjectData.CAH_Second_Approver__c || sobjectData.CAH_CAP_First_Approver__c || sobjectData.CAH_CAP_Second_Approver__c){
								var resObject;
								var reqUrl = 'https://cors-cardinal.herokuapp.com/https://cardinal-buyer-portal-services.secure.force.com/services/apexrest/approval-flow-service'				
								var myBody = {};
								var invoiceAmount = sobjectData.CAH_Gross_Amount__c;
								
								if(sobjectData.CAH_Heroku_Document_Type__c === 'TWA-OUS'){
									invoiceAmount = sobjectData.CAH_Invoice_Amount__c;
								}
								
								if(sobjectData.CAH_Heroku_Work_Type__c == 'Upload Template'){
									invoiceAmount = sobjectData.CAH_Highest_Header_Amount__c;
								}
								
								myBody['CoraAP_Currency'] = sobjectData.CoraAP__Currency__c ? sobjectData.CoraAP__Currency__c : 'USD';
								myBody['invoiceAmount'] = invoiceAmount; //this will come conditionally
								myBody['CAH_Heroku_Work_Type'] = sobjectData.CAH_Heroku_Work_Type__c;
								myBody['CAH_Heroku_Document_Type'] = sobjectData.CAH_Heroku_Document_Type__c;
								myBody['CAH_Tower'] = sobjectData.CAH_Tower__c;
								myBody['CAH_Business_Type'] = sobjectData.CAH_Business_Type__c;
								myBody['CAH_TWA_OUS_Approval_Type'] = sobjectData.CAH_TWA_OUS_Approval_Type__c;
								
								if(sobjectData.CAH_Sourcing_Manager__c){
									if(sobjectData.CAH_Sourcing_Manager__c){
										myBody['approverUserId'] = sobjectData.CAH_Sourcing_Manager__c;
										resObject = performWebServiceCall(reqUrl, myBody);
									}
									
									resObject.then(response => response.json())
									.then(result => {
										if(result.success){
											if(!result.data.isApprovalFlowComplete){
												resolve({
													success: false,
													message: 'Approval hierarchy is not complete for the user you have selected.\nPlease select another user or contact your administrator.'
												});
											}
											else{
												resolve({
													success: true,
													message: 'Success'
												});
											}
										}
										else{
											resolve({
												success: false,
												message: 'Not able to verify approval hierarchy for selected user. Please contact your administrator.'
											});
										}
									});
								}
								
								if(sobjectData.CAH_CAP_First_Approver__c && sobjectData.CAH_CAP_Second_Approver__c){
									var firstApproverCAPMatched = false, secondApproverCAPMatched = false;
									myBody['approverUserId'] = sobjectData.CAH_CAP_First_Approver__c;
									var  resObjectFirstApprover = performWebServiceCall(reqUrl, myBody);
									 resObjectFirstApprover.then(response => response.json())
									.then(result => {
										if(result.success){
											if(result.data.isApprovalFlowComplete){
												firstApproverCAPMatched = true;
											}
											myBody['approverUserId'] = sobjectData.CAH_CAP_Second_Approver__c;
											var resObjectSecondApprover = performWebServiceCall(reqUrl, myBody);
											resObjectSecondApprover.then(response => response.json())
											.then(result => {
												if(result.success){
													if(result.data.isApprovalFlowComplete){
														secondApproverCAPMatched = true;
													}
													if(!firstApproverCAPMatched && !secondApproverCAPMatched){
														resolve({
															success: false,
															message: 'CAP Amount is not matching for either of users. Please select higher approver to proceed. The amount in USD is '+result.data.convertedAmount+'.'
														});
													}
													resolve({
														success: true,
														message: 'Success'
													});
												}
												else{
													resolve({
														success: false,
														message: 'Not able to verify approval limit for selected user. Please contact your administrator.'
													});
												}
											});
										}
										else{
											resolve({
												success: false,
												message: 'Not able to verify approval limit for selected user. Please contact your administrator.'
											});
										}
									});
								}
								
								if(sobjectData.CoraAP__First_Approver__c && sobjectData.CAH_Second_Approver__c){
									myBody['approverUserId'] = sobjectData.CoraAP__First_Approver__c;
									resObject = performWebServiceCall(reqUrl, myBody);
									resObject.then(response => response.json())
									.then(result => {
										if(result.success){
											if(!result.data.isApprovalFlowComplete){
												resolve({
													success: false,
													message: 'Approval hierarchy is not complete for the user you have selected.\nPlease select another user or contact your administrator.'
												});
											}
											else{
												if(!result.data.isUserValidOrNot){
													resolve({
														success: false,
														message: 'The amount in USD is '+result.data.convertedAmount+' and the user '+sobjectData.CoraAP__First_Approver__r.Name+' do not have sufficient approval limit to approve this invoice.'
													});
												}
												else{
													myBody['approverUserId'] = sobjectData.CAH_Second_Approver__c;
													resObject = performWebServiceCall(reqUrl, myBody);
													resObject.then(response => response.json())
													.then(result => {
														if(result.success){
															if(!result.data.isApprovalFlowComplete){
																resolve({
																	success: false,
																	message: 'Approval hierarchy is not complete for the user you have selected.\nPlease select another user or contact your administrator.'
																});
															}
															else{
																if(!result.data.isUserValidOrNot){
																	resolve({
																		success: false,
																		message: 'The amount in USD is '+result.data.convertedAmount+' and the user '+sobjectData.CAH_Second_Approver__r.Name+' do not have sufficient approval limit to approve this invoice.'
																	});
																}
																else{
																	resolve({
																		success: true,
																		message: 'Success'
																	});
																}
															}
														}
														else{
															resolve({
																success: false,
																message: 'Not able to verify approval limit for selected user. Please contact your administrator.'
															});
														}
													});
												}
											}
										}
										else{
											resolve({
												success: false,
												message: 'Not able to verify approval limit for selected users. Please contact your administrator.'
											});
										}
									});
								}
								/*if(invoiceData.CAH_Second_Approver__c){
									myBody['approverUserId'] = invoiceData.CAH_Second_Approver__c;
									resObject = performWebServiceCall(myBody);
								}*/
							}
							else{
								resolve({
									success: true,
									message: 'Success'
								});
							}
						}

						if(sobjectData.CAH_Heroku_Document_Type__c === 'MR11 Reversals'){
							var invoiceAmount = sobjectData.CAH_Gross_Amount__c;
							if(sobjectData.CAH_Heroku_Document_Type__c === 'TWA-OUS'){
								invoiceAmount = sobjectData.CAH_Invoice_Amount__c;
							}
							
							if(sobjectData.CAH_Heroku_Work_Type__c == 'Upload Template'){
								invoiceAmount = sobjectData.CAH_Highest_Header_Amount__c;
							}
							if(sobjectData.CoraAP__Currency__c != 'USD'){
								var myBody = {};
								var resObject;
								var reqUrl = 'https://cors-cardinal.herokuapp.com/https://cardinal-buyer-portal-services.secure.force.com/services/apexrest/amount-conversion-service'
								
								//var reqUrl = 'https://cors-cardinal.herokuapp.com/https://enhuat-cardinal-buyer-portal-services.cs18.force.com/services/apexrest/amount-conversion-service'
									
								myBody['CoraAP_Currency'] = sobjectData.CoraAP__Currency__c;
								myBody['invoiceAmount'] = invoiceAmount;
								resObject = performWebServiceCall(reqUrl, myBody);
								resObject.then(response => response.json())
								.then(result => {
									if(result.success){
										if(result.data.convertedAmount){
											if(result.data.convertedAmount > 10000){
												if(!sobjectData.CAH_Sourcing_Manager__c){
													resolve({
														success: false,
														message: 'Please select approver.'
													});
												}
												else{
													verifyApprovalHierarchy(sobjectData);
												}
											}
											else{
												if(sobjectData.CAH_Sourcing_Manager__c){
													resolve({
														success: false,
														message: 'Please remove sourcing manager. It is not required.'
													});
												}
												else{
													resolve({
														success: true,
														message: 'Success'
													});
												}
											}
										}
										else{
											verifyApprovalHierarchy(sobjectData);
										}
									}
									else{
										resolve({
											success: false,
											message: 'Not able to perform currency conversion. Please verify your network and try again.'
										});
									}
								});
							}
							else{
								if(invoiceAmount > 10000){
									if(!sobjectData.CAH_Sourcing_Manager__c){
										resolve({
											success: false,
											message: 'Please select approver.'
										});
									}
									else{
										verifyApprovalHierarchy(sobjectData);
									}
								}
								else{
									if(sobjectData.CAH_Sourcing_Manager__c){
										resolve({
											success: false,
											message: 'Please remove sourcing manager. It is not required.'
										});
									}
									else{
										var resObject;
										var reqUrl = 'https://cors-cardinal.herokuapp.com/https://cardinal-buyer-portal-services.secure.force.com/services/apexrest/approval-flow-service'
										
										//var reqUrl = 'https://cors-cardinal.herokuapp.com/https://enhuat-cardinal-buyer-portal-services.cs18.force.com/services/apexrest/approval-flow-service'
										var myBody = {};
										myBody['CoraAP_Currency'] = sobjectData.CoraAP__Currency__c;
										myBody['invoiceAmount'] = sobjectData.CAH_Gross_Amount__c;
										myBody['CAH_Heroku_Work_Type'] = sobjectData.CAH_Heroku_Work_Type__c;
										myBody['CAH_Heroku_Document_Type'] = sobjectData.CAH_Heroku_Document_Type__c;
										myBody['CAH_Tower'] = sobjectData.CAH_Tower__c;
										myBody['CAH_Business_Type'] = sobjectData.CAH_Business_Type__c;
										myBody['CAH_TWA_OUS_Approval_Type'] = sobjectData.CAH_TWA_OUS_Approval_Type__c;
										myBody['approverUserId'] = sobjectData.CoraAP__Requestor_Buyer__c;
										resObject = performWebServiceCall(reqUrl, myBody);
										resObject.then(response => response.json())
										.then(result => {
											if(result.success){
												if(!result.data.isApprovalFlowComplete){
													resolve({
														success: false,
														message: 'Approval hierarchy is not complete for the user you have selected.\nPlease select another user or contact your administrator.'
													});
												}
												else{
													resolve({
														success: true,
														message: 'Success'
													});
												}
											}
											else{
												resolve({
													success: false,
													message: 'Not able to perform currency conversion. Please verify your network and try again.'
												});
											}
										});
									}
								}
							}
						}
						else{
							verifyApprovalHierarchy(sobjectData);
						}
					} 
					catch (err) {
						resolve({
							success: false,
							message: 'Some error occured. Please contact administrator.'
						});
					}
					
                })
            },
			validateOnSObjectEdit: async function(sobjectName, viewType, sobjectData, newsobjectData, lineItems, attachmentList, userLocale, userInfo) {
		console.log(sobjectData);
		    var reqBody = JSON.parse(JSON.stringify(newsobjectData));
            console.log('invoiceData===> ', reqBody);
            console.log('******calling approval on hold*************');
            var userAction =  reqBody.CoraAP__Heroku_User_Action__c;
			
		return new Promise((resolve, reject) => {
			try {
				/**********bypass all the validation*******************/
				/*if(newsobjectData.Invoice_Incorrectly_Routed__c==true ){
					resolve({
						success: true,
						message: 'Success'
					});
				}
				/***************************************/
				var polarisNumber = '';
                var invoiceNoValidationString = /[!@#$%^&*? ]/ig;
                
				// This code will checks that the hold days count should not exceed 365 days. Disabled for now as it's not complete.
				function parseDate(str) {
					var mdy = str.split('/');
					return new Date(mdy[2], mdy[0]-1, mdy[1]);
				}
				
				function datediff(first, second) {
					return Math.round((second-first)/(1000*60*60*24));
				}
				//console.log(datediff(parseDate('04/23/2020'), parseDate('04/23/2021')))
				// Comment ends here.
				
				if(sobjectData.CoraAP__Current_State__c === 'Approver Response Received'){
					if(sobjectData.CAH_TWA_OUS_Approval_Type__c === 'DOA'){
						if(sobjectData.hasOwnProperty("CoraAP__First_Approver__c") && 
						sobjectData.hasOwnProperty("CAH_Second_Approver__c") && 
						(sobjectData.CoraAP__First_Approver__c !== undefined && sobjectData.CoraAP__First_Approver__c !== null) &&
						(sobjectData.CAH_Second_Approver__c !== undefined && sobjectData.CAH_Second_Approver__c !== null) &&
						sobjectData.CoraAP__First_Approver__c === sobjectData.CAH_Second_Approver__c){
							return resolve({
								success: false,
								message: 'Both Approvers can not be same.'
							});
						}
					}
					
					if((sobjectData.CAH_Heroku_Document_Type__c === 'Exception to CAP' || sobjectData.CAH_Heroku_Document_Type__c === 'Adobe Sign' || sobjectData.CAH_Heroku_Document_Sub_Category__c === 'Pre-Approved') && 
						sobjectData.CAH_Is_Approval_Email_Attached__c === 'No'){
						return resolve({
							success: false,
							message: 'It is required to attach approval email.'
						});
					}
					
					if(sobjectData.CAH_Notes__c){
						var notesValue = sobjectData.CAH_Notes__c.match(invoiceNoValidationString);
						if(invoiceNoValue || sobjectData.CAH_Notes__c.length > 25){
							return resolve({
								success: false,
								message: 'Header text should contain only alphanumneric values and must not be more than 25 character long.'
							});
						}
					}
				
					if(sobjectData.CAH_Gross_Amount__c !== null && sobjectData.CAH_Gross_Amount__c !== undefined){
						var amount = sobjectData.CAH_Heroku_Work_Type__c == 'Upload Template' ? sobjectData.CAH_Highest_Header_Amount__c : sobjectData.CAH_Net_Amount__c;
						var totalAmount = amount;
						if(sobjectData.hasOwnProperty("CAH_Other_Taxes__c") &&
						(sobjectData.CAH_Other_Taxes__c !== undefined && sobjectData.CAH_Other_Taxes__c !== null)){
							totalAmount += sobjectData.CAH_Other_Taxes__c;
						}
						if(Math.round(sobjectData.CAH_Gross_Amount__c * 100) !== Math.round(totalAmount * 100)){
							return resolve({
								success: false,
								message: 'Please correct gross amount.'
							});
						}
						else if(Math.round(sobjectData.CAH_Gross_Amount__c * 100) !== Math.round(amount * 100)){
							/*reject({
								success: false,
								message: 'Please correct gross amount.'
							});*/
						}
					}
					
					if(sobjectData.CAH_Polaris_number__c !== null && sobjectData.CAH_Polaris_number__c !== undefined){
						var polarisValue = sobjectData.CAH_Polaris_number__c.match(polarisNumber);
						if(polarisValue == null){
							return resolve({
								success: false,
								message: 'Please correct polaris number value.'
							});
						}
					}
					
					//Changes done by Sohil for P2. Start.
					if(sobjectData.CAH_Heroku_Document_Type__c !== 'TWA-OUS' && sobjectData.CoraAP__Invoice_No__c !== null && sobjectData.CoraAP__Invoice_No__c !== undefined && new Date(sobjectData.CreatedDate) > new Date(2021,0,21)){
						var invoiceNoValue = sobjectData.CoraAP__Invoice_No__c.match(invoiceNoValidationString);
						if(invoiceNoValue || sobjectData.CoraAP__Invoice_No__c > 16){
							return resolve({
								success: false,
								message: 'Invoice no should contain only alphanumneric values and must not be more than 16 characters.'
							});
						}
					}
					//Changes done by Sohil for P2. End.
					
					if(sobjectData.CAH_Cost_Center__c !== null && sobjectData.CAH_Cost_Center__c !== undefined){
						if(sobjectData.CAH_Cost_Center__c.toString().length > 10){
							return resolve({
								success: false,
								message: 'Cost Center length can not be more than 10.'
							});
						}
					}
				    // Enhanced Changes Start.	
					if(sobjectData.CAH_Heroku_Work_Type__c === 'Indirect Non PO Invoice' || sobjectData.CAH_Heroku_Work_Type__c == 'Direct Non PO Invoice'){
						if(lineItems && lineItems.length > 0){
                            var taxCodeError = false, indirectTaxCodeError = false, directTaxCodeError = false, amountInNegetive = false;
							for(var i = 0; i < lineItems.length; i++){
								var invoiceLineItem = lineItems[i];
								if(invoiceLineItem.CAH_Amount__c < 0){
									amountInNegetive = true;
									break;
								}
								if((!invoiceLineItem.CAH_Tax_Code__c && (sobjectData.CAH_ERP_System__c === 'Pharma Corp' || sobjectData.CAH_ERP_System__c === 'TPM')) || (!invoiceLineItem.CAH_Tax_Code_Value__c && ((sobjectData.CAH_ERP_System__c !== 'Pharma Corp' && sobjectData.CAH_ERP_System__c !== 'TPM')))){
									taxCodeError = true;
									break;
                                }
								
								 else{
							       if(invoiceLineItem.CAH_Tax_Code__c !== undefined && invoiceLineItem.CAH_Tax_Code__c !== null)
							      {
								  if(sobjectData.CAH_Heroku_Work_Type__c == 'Indirect Non PO Invoice' && !invoiceLineItem.CAH_Tax_Code__r.Name.startsWith('I')){
									indirectTaxCodeError = true;
									break;
								}
									if(sobjectData.CAH_Heroku_Work_Type__c == 'Direct Non PO Invoice' && !invoiceLineItem.CAH_Tax_Code__r.Name.startsWith('D')){
									directTaxCodeError = true;
									break;
								}
							   }
							   if(invoiceLineItem.CAH_Tax_Code_Value__c !== undefined && invoiceLineItem.CAH_Tax_Code_Value__c !== null)
							{
							    if(sobjectData.CAH_Heroku_Work_Type__c == 'Indirect Non PO Invoice' && !invoiceLineItem.CAH_Tax_Code_Value__c.startsWith('I')){
									indirectTaxCodeError = true;
									break;
								}
							      if(sobjectData.CAH_Heroku_Work_Type__c == 'Direct Non PO Invoice' && !invoiceLineItem.CAH_Tax_Code_Value__c.startsWith('D')){
									directTaxCodeError = true;
									break;
								}	
							}	
												
								
							}
								
								
								//Commented Mohana
                                /*else{
									if(sobjectData.CAH_Heroku_Work_Type__c == 'Indirect Non PO Invoice' && !invoiceLineItem.CAH_Tax_Code__r.Name.startsWith('I')){
										indirectTaxCodeError = true;
										break;
									}
									if(sobjectData.CAH_Heroku_Work_Type__c == 'Direct Non PO Invoice' && !invoiceLineItem.CAH_Tax_Code__r.Name.startsWith('D')){
										directTaxCodeError = true;
										break;
									}
								}*/
							}
							//Changes done by Sohil for P2. Start.
							if(amountInNegetive){
								return resolve({
									success: false,
									message: 'Amount can should only be positive on Invoice line item.'
								});
							}
							//Changes done by Sohil for P2. End.
							if(taxCodeError){
								return resolve({
									success: false,
									message: 'Tax code is mandatory on line level.'
								});
                            }
                            if(indirectTaxCodeError){
								return resolve({
									success: false,
									message: 'Please select Tax code as I0 or I1 on line level.'
								});
							}
							if(directTaxCodeError){
								return resolve({
									success: false,
									message: 'Please select Tax code as D0 or D1 on line level.'
								});
							}
                        }
					}
					
					if(sobjectData.CoraAP__Invoice_Date__c !== undefined && sobjectData.CoraAP__Invoice_Date__c !== null){
						//04/23/2020-MM/DD/YYYY
						var invoiceDate = new Date(sobjectData.CoraAP__Invoice_Date__c);
						var currentDate = new Date();
						var difference = datediff(parseDate(currentDate.getMonth()+'/'+currentDate.getDate()+'/'+currentDate.getFullYear()), parseDate(invoiceDate.getMonth()+'/'+invoiceDate.getDate()+'/'+invoiceDate.getFullYear()));
						if(difference > 730){
							return resolve({
								success: false,
								message: 'Invoice date cannot be more than two years in future.'
							});
						}
						if(difference < 0){
							if((difference*-1) > 1095){
								return resolve({
									success: false,
									message: 'Invoice date cannot be more than three years in past.'
								});
							}
						}
					}
				
					var isCostCenterRequired = false;
					var isProfitCenterRequired = false;
					var isCostAndProfitBothSelected = false;
					var isLineTextIssue = false;
                    var isWBSError = false;

					if(sobjectData.CAH_Heroku_Work_Type__c === 'Direct Non PO Invoice' || sobjectData.CAH_Heroku_Work_Type__c === 'Indirect Non PO Invoice'){
						if(lineItems && lineItems.length > 0){
							for(var i = 0; i < lineItems.length; i++){
								var invoiceLineItem = lineItems[i];
								var glCode;
								if(invoiceLineItem.CAH_Text__c){
									var lineTextValue = invoiceLineItem.CAH_Text__c.match(invoiceNoValidationString);
									if(lineTextValue || invoiceLineItem.CAH_Text__c.length > 25){
										isLineTextIssue = true;
										break;
									}
								}
								if((sobjectData.CAH_ERP_System__c === 'TPM' || sobjectData.CAH_ERP_System__c === 'Pharma Corp') && invoiceLineItem.CoraAP__GL_Code__r.Name){

									if(invoiceLineItem.CAH_WBS__c && invoiceLineItem.CAH_WBS__r.Name && !invoiceLineItem.CAH_WBS__r.Name.startsWith('B')){
										isWBSError = true;
										break
									}
									
									if(invoiceLineItem.CAH_WBS__c && invoiceLineItem.CAH_WBS__r.Name && invoiceLineItem.CAH_WBS__r.Name.startsWith('B')){
									
									} else{
										glCode = '' + parseInt(invoiceLineItem.CoraAP__GL_Code__r.Name);
										if(invoiceLineItem.CoraAP__GL_Code__r.Name && 
										( glCode.startsWith('1') || glCode.startsWith('2') || glCode.startsWith('3')  || glCode.startsWith('4') || glCode.startsWith('5'))) {
											if(!invoiceLineItem.CAH_Profit_Center__c){
												isProfitCenterRequired = true;
												break;
											}
											if(invoiceLineItem.CAH_Profit_Center__c && invoiceLineItem.CoraAP__CostCode__c){
												isCostAndProfitBothSelected = true;
												break;
											}
										}
										else if(invoiceLineItem.CoraAP__GL_Code__r.Name && (glCode.startsWith('6') || glCode.startsWith('7') || glCode.startsWith('8'))){
											if(!invoiceLineItem.CoraAP__CostCode__c){
												isCostCenterRequired = !invoiceLineItem.CoraAP__CostCode__c;
												//isProfitCenterRequired = !invoiceLineItem.CAH_Profit_Center__c;
												break;
											}
											if(invoiceLineItem.CAH_Profit_Center__c && invoiceLineItem.CoraAP__CostCode__c){
												isCostAndProfitBothSelected = true;
												break;
											}
										}
									}
								}
								else if((sobjectData.CAH_ERP_System__c !== 'TPM' && sobjectData.CAH_ERP_System__c !== 'Pharma Corp') && invoiceLineItem.CAH_GL_Code_text__c){
									if(sobjectData.CAH_ERP_System__c !== 'SAP by Design' && sobjectData.CAH_ERP_System__c !== 'FACTS' && sobjectData.CAH_ERP_System__c !== 'JDE' && sobjectData.CAH_ERP_System__c !== 'PRMS' && sobjectData.CAH_ERP_System__c !== 'BPCS' && sobjectData.CAH_ERP_System__c !== 'MAPICS' && sobjectData.CAH_ERP_System__c !== 'Ariba'){

										if(invoiceLineItem.CAH_WBS_text__c !== undefined && invoiceLineItem.CAH_WBS_text__c !== null && !invoiceLineItem.CAH_WBS_text__c.startsWith('B')){
											isWBSError = true;
											break;
										}
	
										if(invoiceLineItem.CAH_WBS_text__c !== undefined && invoiceLineItem.CAH_WBS_text__c !== null && invoiceLineItem.CAH_WBS_text__c.startsWith('B')){
										} else{

											glCode = '' + parseInt(invoiceLineItem.CAH_GL_Code_text__c);
											if(!invoiceLineItem.CAH_Profit_Center_text__c && 
											(glCode.startsWith('1') || glCode.startsWith('2') || glCode.startsWith('3') || glCode.startsWith('4') || glCode.startsWith('5'))){
												isProfitCenterRequired = true;
												break;
											}
											else if((!invoiceLineItem.CAH_Profit_Center_text__c || !invoiceLineItem.CAH_Cost_Center__c) && 
											(glCode.startsWith('6') || glCode.startsWith('7') || glCode.startsWith('8'))){                    
												isCostCenterRequired = !invoiceLineItem.CAH_Cost_Center__c;
												//isProfitCenterRequired = !invoiceLineItem.CAH_Profit_Center_text__c;
												break;
											}
										}
									}
									else{
										if(sobjectData.CAH_ERP_System__c === 'SAP by Design'){
											isCostCenterRequired = !invoiceLineItem.CAH_Cost_Center__c;
										}
									}
								}
							}
							
							if(isCostCenterRequired){        
								return resolve({
									success: false,
									message: 'Please select at least one Cost Center'
								});
							}
							
							if(isProfitCenterRequired){
								return resolve({
									success: false,
									message: 'Please select at least one Profit Center'
								});
							}
							
							if(isCostAndProfitBothSelected){
								return resolve({
									success: false,
									message: 'Please select either cost center or profit center'
								});
							}
							if(isLineTextIssue){
								return resolve({
									success: false,
									message: 'Text should contain only alphanumneric values and must not be more than 25 character long.'
								});
							}
						}
					}
					
					var amt = sobjectData.CAH_Gross_Amount__c;
					if(sobjectData.CAH_Heroku_Document_Type__c === 'TWA-OUS'){
						amt = sobjectData.CAH_Invoice_Amount__c;
					}
					
					if(sobjectData.CAH_Heroku_Work_Type__c == 'Upload Template'){
						amt = sobjectData.CAH_Highest_Header_Amount__c;
					}
					if(amt < 0){
						return resolve({
							success: false,
							message: 'Negative amount not allowed.'
						});
					}
					
					//Credit Memo check removed by Sohil for P2.
					//if(invoiceData.lineItem && invoiceData.lineItem.length > 0 && invoiceData.CAH_Net_Amount__c && invoiceData.CAH_Heroku_Document_Type__c != 'Credit Memo'){
					if(lineItems && lineItems.length > 0 && sobjectData.CAH_Net_Amount__c && userAction!='Send back to Processor'){
						var headerAmt = sobjectData.CAH_Net_Amount__c;
						/*if(invoiceData.CAH_Heroku_Document_Type__c === 'TWA-OUS'){
							invoiceAmount = invoiceData.CAH_Invoice_Amount__c;
						}
						
						if(invoiceData.CAH_Heroku_Work_Type__c == 'Upload Template'){
							invoiceAmount = invoiceData.CAH_Highest_Header_Amount__c;
						}*/
						
						var lineLevelAmt = 0.0;
						for (var j = 0; j < lineItems.length; j++) {
							if(lineItems[j].isDeleted !== true){
								var amt = lineItems[j].CAH_Amount__c ? lineItems[j].CAH_Amount__c : 0.0;
								lineLevelAmt = +lineLevelAmt + +amt;	
							}
						}
						console.log('test headerAmt is '+headerAmt + ' test lineLevelAmt is '+lineLevelAmt);
						if (Math.round(headerAmt * 100) !== Math.round(lineLevelAmt * 100)) {
							console.log('test in differenct amount block');
							return resolve({
								success: false,
								message: 'Header Net Amount is greater than sum of line items by ' + ((headerAmt-lineLevelAmt).toFixed(2))
							});
						}
					}
					
                    var isCCandPCMismatch = false;
                    if(sobjectData.CAH_Heroku_Work_Type__c === 'Indirect Non PO Invoice' && (sobjectData.CAH_ERP_System__c === 'TPM' || (sobjectData.CAH_ERP_System__c === 'Pharma Corp' && sobjectData.CoraAP__Bill_To_Country__c !== 'Canada' ))){
						for(var i = 0; i<lineItems.length; i++){
							var invoiceLineItem = lineItems[i];
							if( invoiceLineItem.CoraAP__CostCode__c && invoiceLineItem.CoraAP__APLegalEntity__c ){
								var companyCodeVal = invoiceLineItem.CoraAP__APLegalEntity__r ? invoiceLineItem.CoraAP__APLegalEntity__r.Name.substring(0,3) : '';
								var profitCenterVal = invoiceLineItem.CoraAP__CostCode__r ? invoiceLineItem.CoraAP__CostCode__r.Name : '';
								if( companyCodeVal && profitCenterVal &&  !eval('/'+companyCodeVal+'.*/').test(profitCenterVal)){
									isCCandPCMismatch = true;
									break;
								}
							}
						}
					}
					
					if(isCCandPCMismatch){
						return resolve({
							success: false,
							message: 'Invoice line item\'s Company Code and Cost Center are mismatched.'
						});
					}
					
					/*if(invoiceData.hasOwnProperty('CoraAP__Invoice_Date__c') && !invoiceData.CoraAP__Invoice_Date__c){
						reject({
							success: false,
							message: 'Please select Invoice Date.'
						});
					}*/
				
					var performWebServiceCall = (url, myBody) => {
						return fetch(url, {
							method: 'POST',
							body: JSON.stringify(myBody),
							headers: {
								'Content-Type': 'application/json'
							}
						});
					}
							
					var verifyApprovalHierarchy = (sobjectData) => {
						if(sobjectData.CAH_Sourcing_Manager__c || sobjectData.CoraAP__First_Approver__c || sobjectData.CAH_Second_Approver__c || sobjectData.CAH_CAP_First_Approver__c || sobjectData.CAH_CAP_Second_Approver__c){
							var resObject;
							var reqUrl = 'https://cors-cardinal.herokuapp.com/https://cardinal-buyer-portal-services.secure.force.com/services/apexrest/approval-flow-service'
							
							//var reqUrl = 'https://cors-cardinal.herokuapp.com/https://enhuat-cardinal-buyer-portal-services.cs18.force.com/services/apexrest/approval-flow-service'
							var myBody = {};
							var invoiceAmount = sobjectData.CAH_Gross_Amount__c;
							
							if(sobjectData.CAH_Heroku_Document_Type__c === 'TWA-OUS'){
								invoiceAmount = sobjectData.CAH_Invoice_Amount__c;
							}
							
							if(sobjectData.CAH_Heroku_Work_Type__c == 'Upload Template'){
								invoiceAmount = sobjectData.CAH_Highest_Header_Amount__c;
							}
							
							myBody['CoraAP_Currency'] = sobjectData.CoraAP__Currency__c;
							myBody['invoiceAmount'] = invoiceAmount; //this will come conditionally
							myBody['CAH_Heroku_Work_Type'] = sobjectData.CAH_Heroku_Work_Type__c;
							myBody['CAH_Heroku_Document_Type'] = sobjectData.CAH_Heroku_Document_Type__c;
							myBody['CAH_Tower'] = sobjectData.CAH_Tower__c;
							myBody['CAH_Business_Type'] = sobjectData.CAH_Business_Type__c;
							myBody['CAH_TWA_OUS_Approval_Type'] = sobjectData.CAH_TWA_OUS_Approval_Type__c;
							
							if(sobjectData.CAH_Sourcing_Manager__c){
								if(sobjectData.CAH_Sourcing_Manager__c){
									//myBody['approverUserId'] = 'a2O6g000000AHOB';
									myBody['approverUserId'] = sobjectData.CAH_Sourcing_Manager__r.Id;
									resObject = performWebServiceCall(reqUrl, myBody);
								}
								
								resObject.then(response => response.json())
								.then(result => {
									if(result.success){
										if(!result.data.isApprovalFlowComplete){
											return resolve({
												success: false,
												message: 'Approval hierarchy is not complete for the user you have selected.\nPlease select another user or contact your administrator.'
											});
										}
										else{
											resolve({
												success: true,
												message: 'Success'
											});
										}
									}
									else{
										return resolve({
											success: false,
											message: 'Not able to verify approval hierarchy for selected user. Please contact your administrator.'
										});
									}
								});
							}
							
							if(sobjectData.CAH_CAP_First_Approver__c && sobjectData.CAH_CAP_Second_Approver__c){
								var firstApproverCAPMatched = false, secondApproverCAPMatched = false;
								myBody['approverUserId'] = sobjectData.CAH_CAP_First_Approver__c;
								resObjectFirstApprover = performWebServiceCall(reqUrl, myBody);
								resObjectFirstApprover.then(response => response.json())
								.then(result => {
									if(result.success){
										if(result.data.isApprovalFlowComplete){
											firstApproverCAPMatched = true;
										}
										myBody['approverUserId'] = sobjectData.CAH_CAP_Second_Approver__c;
										resObjectSecondApprover = performWebServiceCall(reqUrl, myBody);
										resObjectSecondApprover.then(response => response.json())
										.then(result => {
											if(result.success){
												if(result.data.isApprovalFlowComplete){
													secondApproverCAPMatched = true;
												}
												if(!firstApproverCAPMatched && !secondApproverCAPMatched){
													return resolve({
														success: false,
														message: 'CAP Amount is not matching for either of users. Please select higher approver to proceed. The amount in USD is '+result.data.convertedAmount+'.'
													});
												}
												resolve({
													success: true,
													message: 'Success'
												});
											}
											else{
												return resolve({
													success: false,
													message: 'Not able to verify approval limit for selected user. Please contact your administrator.'
												});
											}
										});
									}
									else{
										return resolve({
											success: false,
											message: 'Not able to verify approval limit for selected user. Please contact your administrator.'
										});
									}
								});
							}
							
							if(sobjectData.CoraAP__First_Approver__c && sobjectData.CAH_Second_Approver__c){
								myBody['approverUserId'] = sobjectData.CoraAP__First_Approver__c;
								resObject = performWebServiceCall(reqUrl, myBody);
								resObject.then(response => response.json())
								.then(result => {
									if(result.success){
										if(!result.data.isApprovalFlowComplete){
											return resolve({
												success: false,
												message: 'Approval hierarchy is not complete for the user you have selected.\nPlease select another user or contact your administrator.'
											});
										}
										else{
											if(!result.data.isUserValidOrNot){
												return resolve({
													success: false,
													message: 'The amount in USD is '+result.data.convertedAmount+' and the user '+sobjectData.CoraAP__First_Approver__r.Name+' do not have sufficient approval limit to approve this invoice.'
												});
											}
											else{
												myBody['approverUserId'] = sobjectData.CAH_Second_Approver__c;
												resObject = performWebServiceCall(reqUrl, myBody);
												resObject.then(response => response.json())
												.then(result => {
													if(result.success){
														if(!result.data.isApprovalFlowComplete){
															return resolve({
																success: false,
																message: 'Approval hierarchy is not complete for the user you have selected.\nPlease select another user or contact your administrator.'
															});
														}
														else{
															if(!result.data.isUserValidOrNot){
																return resolve({
																	success: false,
																	message: 'The amount in USD is '+result.data.convertedAmount+' and the user '+sobjectData.CAH_Second_Approver__r.Name+' do not have sufficient approval limit to approve this invoice.'
																});
															}
															else{
																resolve({
																	success: true,
																	message: 'Success'
																});
															}
														}
													}
													else{
														return resolve({
															success: false,
															message: 'Not able to verify approval limit for selected user. Please contact your administrator.'
														});
													}
												});
											}
										}
									}
									else{
										return resolve({
											success: false,
											message: 'Not able to verify approval limit for selected users. Please contact your administrator.'
										});
									}
								});
							}
							/*if(invoiceData.CAH_Second_Approver__c){
								myBody['approverUserId'] = invoiceData.CAH_Second_Approver__c;
								resObject = performWebServiceCall(myBody);
							}*/
						}
						else{
							resolve({
								success: true,
								message: 'Success'
							});
						}
					}

					if(sobjectData.CAH_Heroku_Document_Type__c === 'MR11 Reversals'){
						var invoiceAmount = sobjectData.CAH_Gross_Amount__c;
						if(sobjectData.CAH_Heroku_Document_Type__c === 'TWA-OUS'){
							invoiceAmount = sobjectData.CAH_Invoice_Amount__c;
						}
						
						if(sobjectData.CAH_Heroku_Work_Type__c == 'Upload Template'){
							invoiceAmount = sobjectData.CAH_Highest_Header_Amount__c;
						}
						if(sobjectData.CoraAP__Currency__c != 'USD'){
							var myBody = {};
							var resObject;
							var reqUrl = 'https://cors-cardinal.herokuapp.com/https://cardinal-buyer-portal-services.secure.force.com/services/apexrest/amount-conversion-service'
							
							//var reqUrl = 'https://cors-cardinal.herokuapp.com/https://enhuat-cardinal-buyer-portal-services.cs18.force.com/services/apexrest/amount-conversion-service'
							myBody['CoraAP_Currency'] = sobjectData.CoraAP__Currency__c;
							myBody['invoiceAmount'] = invoiceAmount;
							resObject = performWebServiceCall(reqUrl, myBody);
							resObject.then(response => response.json())
							.then(result => {
								if(result.success){
									if(result.data.convertedAmount){
										if(result.data.convertedAmount > 10000){
											if(!sobjectData.CAH_Sourcing_Manager__c){
												return resolve({
													success: false,
													message: 'Please select approver.'
												});
											}
											else{
												verifyApprovalHierarchy(sobjectData);
											}
										}
										else{
											if(sobjectData.CAH_Sourcing_Manager__c){
												return resolve({
													success: false,
													message: 'Please remove sourcing manager. It is not required.'
												});
											}
											else{
												resolve({
													success: true,
													message: 'Success'
												});
											}
										}
									}
									else{
										verifyApprovalHierarchy(sobjectData);
									}
								}
								else{
									return resolve({
										success: false,
										message: 'Not able to perform currency conversion. Please verify your network and try again.'
									});
								}
							});
						}
						else{
							if(invoiceAmount > 10000){
								if(!sobjectData.CAH_Sourcing_Manager__c){
									return resolve({
										success: false,
										message: 'Please select approver.'
									});
								}
								else{
									verifyApprovalHierarchy(sobjectData);
								}
							}
							else{
								if(sobjectData.CAH_Sourcing_Manager__c){
									return resolve({
										success: false,
										message: 'Please remove sourcing manager. It is not required.'
									});
								}
								else{
									var resObject;
									var reqUrl = 'https://cors-cardinal.herokuapp.com/https://cardinal-buyer-portal-services.secure.force.com/services/apexrest/approval-flow-service'
									
									//var reqUrl = 'https://cors-cardinal.herokuapp.com/https://enhuat-cardinal-buyer-portal-services.cs18.force.com/services/apexrest/approval-flow-service'
									var myBody = {};
									myBody['CoraAP_Currency'] = sobjectData.CoraAP__Currency__c;
									myBody['invoiceAmount'] = sobjectData.CAH_Gross_Amount__c;
									myBody['CAH_Heroku_Work_Type'] = sobjectData.CAH_Heroku_Work_Type__c;
									myBody['CAH_Heroku_Document_Type'] = sobjectData.CAH_Heroku_Document_Type__c;
									myBody['CAH_Tower'] = sobjectData.CAH_Tower__c;
									myBody['CAH_Business_Type'] = sobjectData.CAH_Business_Type__c;
									myBody['CAH_TWA_OUS_Approval_Type'] = sobjectData.CAH_TWA_OUS_Approval_Type__c;
									myBody['approverUserId'] = sobjectData.CoraAP__Requestor_Buyer__c;
									resObject = performWebServiceCall(reqUrl, myBody);
									resObject.then(response => response.json())
									.then(result => {
										if(result.success){
											if(!result.data.isApprovalFlowComplete){
												return resolve({
													success: false,
													message: 'Approval hierarchy is not complete for the user you have selected.\nPlease select another user or contact your administrator.'
												});
											}
											else{
												resolve({
													success: true,
													message: 'Success'
												});
											}
										}
										else{
											return resolve({
												success: false,
												message: 'Not able to perform currency conversion. Please verify your network and try again.'
											});
										}
									});
								}
							}
						}
					}
					else{
						verifyApprovalHierarchy(sobjectData);
					}
				}
				else{
					if((sobjectData.CoraAP__Current_State__c === 'Awaiting Approver Response' || sobjectData.CoraAP__Current_State__c === 'Pending For Clarification') && newsobjectData.CoraAP__Hold_Date__c !== undefined && newsobjectData.CoraAP__Hold_Date__c !== null){
						//04/23/2020-MM/DD/YYYY
						var holdDate = new Date(newsobjectData.CoraAP__Hold_Date__c);
						var currentDate = new Date();
						var difference = datediff(parseDate(currentDate.getMonth()+'/'+currentDate.getDate()+'/'+currentDate.getFullYear()), parseDate(holdDate.getMonth()+'/'+holdDate.getDate()+'/'+holdDate.getFullYear()));
						if(difference > 365){
							return resolve({
								success: false,
								message: 'Hold days cannot be more than 365.'
							});
						}
						if(difference < 0){
							return resolve({
								success: false,
								message: 'Hold days cannot be in past.'
							});
						}
					}
					
					//Credit Memo check removed by Sohil for P2.
					//if(invoiceData.lineItem && invoiceData.lineItem.length > 0 && invoiceData.CoraAP__Invoice_Type__c != 'Credit Memo'){
					if(lineItems && lineItems.length > 0 && userAction!='Send back to Processor'){
						var headerAmt = sobjectData.CAH_Net_Amount__c;
						if(sobjectData.CoraAP__Invoice_Type__c === 'TWA-OUS' || sobjectData.CAH_Heroku_Document_Type__c === 'TWA-OUS'){
							headerAmt = sobjectData.CAH_Invoice_Amount__c;
						}
						
						if(sobjectData.CoraAP__Document_Type__c == 'Upload Template' || sobjectData.CAH_Heroku_Work_Type__c == 'Upload Template'){
							headerAmt = sobjectData.CAH_Highest_Header_Amount__c;
						}
						
						var lineLevelAmt = 0.0;
						for (var j = 0; j < lineItems.length; j++) {
							if(lineItems[j].isDeleted !== true){
								var amt = lineItems[j].CAH_Amount__c ? lineItems[j].CAH_Amount__c : 0.0;
								lineLevelAmt = +lineLevelAmt + +amt;	
							}
						}
						console.log('test headerAmt is '+headerAmt + ' test lineLevelAmt is '+lineLevelAmt);
						if (Math.round(headerAmt * 100) !== Math.round(lineLevelAmt * 100)) {
							console.log('test in differenct amount block');
							return resolve({
								success: false,
								message: 'Header Net Amount is greater than sum of line items by ' + ((headerAmt-lineLevelAmt).toFixed(2))
							});
						}
					}
					
					
					if(sobjectData.CAH_Net_Amount__c && sobjectData.CoraAP__Current_State__c === 'Pending For Coding') {
                        
						var netamount =  sobjectData.CAH_Net_Amount__c ? parseFloat(sobjectData.CAH_Net_Amount__c) : 0.0;
    
                        var grossAmount = sobjectData.CAH_Gross_Amount__c ? parseFloat(sobjectData.CAH_Gross_Amount__c) : 0.0;

                        var freightCharges = sobjectData.CAH_Freight_Charges__c ? parseFloat(sobjectData.CAH_Freight_Charges__c) : 0.0;
                        
                        var dropshipCharges = sobjectData.CAH_Dropship_Charges__c ? parseFloat(sobjectData.CAH_Dropship_Charges__c) : 0.0;
                        
                        var miscCharges = sobjectData.CAH_Misc_Allowances_Goodwill_Credit__c ?  parseFloat(sobjectData.CAH_Misc_Allowances_Goodwill_Credit__c) : 0.0;
                        
                        var otherCharges = sobjectData.CAH_All_other_charges_incidental__c ?  parseFloat(sobjectData.CAH_All_other_charges_incidental__c) : 0.0;
                        
                        var othertax = sobjectData.CAH_Other_Taxes__c ?  parseFloat(sobjectData.CAH_Other_Taxes__c) : 0.0;
                        
                        var specialHandlingCharges = sobjectData.CAH_Special_Handling_Charges__c ?  parseFloat(sobjectData.CAH_Special_Handling_Charges__c) : 0.0;

                        var federalExciseStateTax = sobjectData.CAH_Federal_Excise_Tax_State_Tax__c ?  parseFloat(sobjectData.CAH_Federal_Excise_Tax_State_Tax__c) : 0.0;

                        var allAddedAmount = netamount + othertax + freightCharges + dropshipCharges + miscCharges + otherCharges + specialHandlingCharges + federalExciseStateTax; 
                        
                        if (Math.round(grossAmount * 100) !== Math.round(allAddedAmount * 100)) {
                            return resolve({
                                success: false,
                                message: 'All charges, taxes and net amount should be matching with Gross Amount.'
                            });
                        }
						
						var amt = sobjectData.CAH_Gross_Amount__c;
						if(sobjectData.CAH_Heroku_Document_Type__c === 'TWA-OUS'){
							amt = sobjectData.CAH_Invoice_Amount__c;
						}
						
						if(sobjectData.CAH_Heroku_Work_Type__c == 'Upload Template'){
							amt = sobjectData.CAH_Highest_Header_Amount__c;
						}
						if(amt < 0){
							return resolve({
								success: false,
								message: 'Negative amount not allowed.'
							});
						}
						
						//Changes done by Sohil for P2. Start.
						if(sobjectData.CAH_Heroku_Work_Type__c == 'Indirect Non PO Invoice' || sobjectData.CAH_Heroku_Work_Type__c == 'Direct Non PO Invoice'){
							if(lineItems && lineItems.length > 0){
								var amountInNegetive = false;
								for(var i = 0; i < lineItems.length; i++){
									var invoiceLineItem = lineItems[i];
									if(invoiceLineItem.CAH_Amount__c < 0){
										amountInNegetive = true;
										break;
									}
								}								
								if(amountInNegetive){
									return resolve({
										success: false,
										message: 'Amount can should only be positive on Invoice line item.'
									});
								}
							}
						}
						//Changes done by Sohil for P2. End.
                    }

					
					
					var isCCandPCMismatch = false;
					if((sobjectData.CoraAP__Document_Type__c === 'Indirect Non PO Invoice' || sobjectData.CAH_Heroku_Work_Type__c === 'Indirect Non PO Invoice') && (sobjectData.CAH_ERP_System__c === 'TPM' || (sobjectData.CAH_ERP_System__c === 'Pharma Corp' && sobjectData.CoraAP__Bill_To_Country__c !== 'Canada' ))){
						for(var i = 0; i<lineItems.length; i++){
							var invoiceLineItem = lineItems[i];
							if( invoiceLineItem.CoraAP__CostCode__c && invoiceLineItem.CoraAP__APLegalEntity__c ){
								var companyCodeVal = invoiceLineItem.CoraAP__APLegalEntity__r ? invoiceLineItem.CoraAP__APLegalEntity__r.Name.substring(0,3) : '';
								var profitCenterVal = invoiceLineItem.CoraAP__CostCode__r ? invoiceLineItem.CoraAP__CostCode__r.Name : '';
								if( companyCodeVal && profitCenterVal &&  !eval('/'+companyCodeVal+'.*/').test(profitCenterVal)){
									isCCandPCMismatch = true;
									break;
								}
							}
						}
					}
					
					if(isCCandPCMismatch){
						return resolve({
							success: false,
							message: 'Invoice line item\'s Company Code and Cost Center are mismatched.'
						});
					}
					
					//Chnages for Coding done validation - CAF-3006
				if(sobjectData.CAH_Heroku_Document_Type__c === 'Regular Invoice' && sobjectData.CoraAP__Current_State__c === 'Pending For Coding' && newsobjectData.CoraAP__Heroku_User_Action__c !== 'Coding Done'){
					if(lineItems && lineItems.length > 0){
								var isLineItemUpdated = false;
								for(var i = 0; i < lineItems.length; i++){
									var invoiceLineItem = lineItems[i];
									if(invoiceLineItem.isUpdated === true || invoiceLineItem.isDeleted === true){
										isLineItemUpdated = true;
										break;
									}
								}								
								if(isLineItemUpdated){
									return resolve({
										success: false,
										message: 'You have edited the Coding details please use the <b>Coding Done</b> button.'
									});
								}
							}
				}
				
					resolve({
						success: true,
						message: 'Success'
					});
				}
			} 
			catch (err) {
				resolve({
					success: false,
					message: 'Some error occured. Please contact administrator.'
				});
			}
		});
	}
})